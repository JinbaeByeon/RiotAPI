from distutils.core import setup, Extension

setup(name = 'LOL Search',
      version = '1.0',
      py_modules = ['RiotAPI','UserData']
      )
